import {
  Dimensions,
  FlatList,
  Image,
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useLayoutEffect, useState, version} from 'react';
import {useNavigation} from '@react-navigation/native';
import StarRating from 'react-native-star-rating-widget';
import RNImmediatePhoneCall from 'react-native-immediate-phone-call';
import DatePicker from 'react-native-date-picker';
import Icon from 'react-native-vector-icons/FontAwesome';
import Icon2 from 'react-native-vector-icons/FontAwesome5';
import Colors from '../../components/Colors';
import {Dropdown} from 'react-native-element-dropdown';

const Home = () => {
  const navigation = useNavigation();
  const [date, setDate] = useState(new Date());
  const [dateSelected, setDateSelected] = useState(false)
  const [open, setOpen] = useState(false);
  const [goodsName, setGoodsName] = useState(null);
  const [FareType, setFareType] = useState(null);
  const [noVehicles, setNoVehicles] = useState(null);
  const [atlerNumber, setAlterNUmber] = useState(null);
  const [selectedVehicle, setSelectedVehicle] = useState(null);

  useLayoutEffect(() => {
    navigation.setOptions({
      headerLeft: () => (
        <TouchableOpacity
          style={{marginLeft: width * 0.04}}
          onPress={() => navigation.toggleDrawer()}>
          <Icon name="reorder" size={25} color="#000" />
        </TouchableOpacity>
      ),
      headerTitle: () => (
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'center',
            alignItems: 'center',
            gap: 5,
          }}>
          <Text style={{color: 'black', fontSize: 18}}>Book a Pickup</Text>
          <Icon2 name="truck" size={20} color="#000" />
        </View>
      ),
      headerRight: () => (
        <TouchableOpacity
          style={{marginRight: width * 0.04}}
          onPress={() => navigation.navigate('Notifications')}>
          <Text
            style={{
              position: 'absolute',
              top: -4,
              right: -4,
              backgroundColor: Colors.red,
              fontSize: 12,
              paddingHorizontal: width * 0.01,
              borderRadius: 25,
              zIndex: 5,
            }}>
            1
          </Text>
          <Icon name="bell" size={23} color={Colors.primaryColor} />
        </TouchableOpacity>
      ),
    });
  }, []);

  const VehicleData = [
    {
      name: 'Tata ace',
      weight: 500,
      img: 'https://5.imimg.com/data5/QO/IQ/VY/GLADMIN-3061/tata-ace-zip-cng-pickup-truck-payload-500-kg-250x250.jpg',
    },
    {
      name: 'Bolero',
      weight: 500,
      img: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBQUFBgVFRQZGBgaGxsYGBsbGxsbGx0gGhgbGxsaGxsbIC0lHB4pIBsZJTcmKS8wNDQ0GyM5PzkyPi00NDABCwsLEA8QGxISHTIgJCkyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIwMjIyMjIyMjIyMjAyMjIyMjAyMDsyP//AABEIALcBEwMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAABQYDBAcCAQj/xABNEAACAQIEAgcEBQgEDAcAAAABAgMAEQQSITEFQQYTIlFhcYEykaGxFCNCYnIHUoKDkrLB0UPCw/AWJDNTY3OToqPS4fEVF0RUhLPT/8QAGAEBAQEBAQAAAAAAAAAAAAAAAAECAwT/xAAeEQEBAAIDAQEBAQAAAAAAAAAAAQIREiExUUEiA//aAAwDAQACEQMRAD8A7JSlKBSlKBSlKBSlKBSlKBSlKBSlKBSozH8ewkOkuJiQ7WZ1BPgFvcmorEdOsEvstJIfuRvb9pgF+NNmlopVFm/KFe/V4ORu7O6IPXJnI91R+I6dY4js4eCLxd3k/wCS9TlF410qlcfl6ZY9tDjIE/AiE+l2etN+MY175sdiW/1aFR6FY0+dTa6dspXB5mkb25cW/wCKVlHqOtPyrRxGGjPtQh/xylv6tXv4nX1+hA42uPfXqvzXCiNiY4/o8KqNTZTqWVwLnc2sD6VbsJh5l1hdpEGzYXESE/7LMrIPR6nJdOzUrl3DelOIVsgxOcjeOdA7ftRiORfMxtVowXTBWH1sLJbd4z16DzyAOn6aLSZRLjVppWnw/iUU654ZUkXvRgw8jY6GtytIUpSgUpSgUpSgUpSgUpSgUpSgUpSgUpSgUpSgUJpWjxjGdTE7gXYWCL+c7HKi+rECgqnGOO42SaSDCQ9mM5HkV09ogHLd1IUgEXFj51Cz8Dx83+WaMg7iSaSQfsKAnwq28IwIgiWMtmbV3b8+RyWkf1Yk+AsKzShfEeRpxl9OVinQdEnQWM8aDujhH8X/AIVm/wAH419qeVvLKnyX+NTs8fc9vMXqFxWKIYqdxzqzCJc6R8AjbVY2cd7yOR4gXa1G4Aq+zDCD5C9/MitZuMTRpZbhRexyX3JJ1871F4jpFKb/AFlvAWq6Zt2zzYzLdbAW0OltvKo2fiB8PcP5VG4nGEm5NydSa0JsTVElPxBvzj7zUbLiq05J61zJr/flUElwe2cyHfO9vKOM3/eFRkQKkEEq2moJB08RUxhMOwjhH2mgnk9JJEjB91ar4NxuKxj23l1puxdI8RlCSFZ0/NmUP7mOoqY4Zjg4WTMYUyl+cuXs30znNl7J0VhVZGHNTPDoj1QTuEie55FHwKms54z8awyt9WCKUyNnQxYlgLdZE5SceAVisn/EPlUvgukssbiMYjtXP1WKQ5zbkrgI488slczeA38e/wD61Iw8SnVQjSZ0NxkkAkT2SRo2o25GnGzw5S+u6cK4iJkvYKw0ZQwax8DoSPMA+AqQrln5NsQHxBFigCMAis2QFSosFJOntG221dUrUqV8pSlVClKUClKUClKUClKUClKUClKUClKUCq5jZutxFv6ODTwaRl1P6CMB5yNzWvnTLjMuGSNYQpklkEaFhcL2SS1ufIeGa+u1R8bCOMJe51JPNmYlnY+JYsfWrIlrelxG9ac+LA51EcS4ska3dgt9B3knko3J8BVfx3EpWHZZYx3EZn9dQEO+lzy8QNCyz8QA51WsXjTncm4BJ1qv4mSVjYzMR+O3nfu9DWuyv/nPif51Ns6WhMb2F15X9+tR+NxYOhAY+IBAqJ650XVs3cLFj42A1t4nQd4rA8jvv2R3WPz0v6aeJpasj1iGj12B8P5Co9nPn/fat9OHudVUW77GsEnB2O/yrPKHG/Gk9/GsYJAY+Fh5nb4XrdfhJHL4CtrgnCzJiIY7dlpFZvKMF2uO7KG18RU2swq34Hh18W8Y1EGFwuHv4lc59brVa4pKescCR7A6AGwAI2AHgRrzq3cMxzwYrFSTYeZo5Z37UaZ7BCqxsddimf3iuf4/iSGV9cvaIsQQez2db89KmLeU7Xjo3wETRJI5Jui6g2JawLX8AawJD1ZYEWyyH3MiP/VerP8Ak3nV8EliG3FgRmuLA6b2/lUd0nwpSSU7XWBrekyN81q5+Jh6134Pla+VNORRSPiKx43hQDKyplBaI2GwzOEYDwuWq7YaDrI0fTtIrftKDWvxuAR4eSTbq4y9/wDVt1l/DatM6QnRWLqcaqbdqx8mjZvmw91dQrnuKj6viq2/zaN75UT5K1dCrE9rV8hSlK0hSlKBSlKBSlKBShNUji3TaJs0eFmiL7Z2dSAb65UFyTvvb1qWyLJtd6xyTIvtMF8yB865lLjsURd8VFl5lo5nHxlVfcK1xjQv/qYwf9HhIx8WLVnl8a4/XRpOPYRdDiYr92dSfcDetdulOEG0hb8KO3yWqCnEndlRcZOWYhVVEw6C5/VG3nsBrWfFTdW2V8TiXN7dmRtT90JGpbzUECx1FTeVXjj9XBulkX2YcQ3lEw+dq136WSfZwM588q/OqbxbFRwlV6ySRmUOR9In7IYXXNdxqRrbusedRL8WjP8AQK34nkb95ql5GsVr43isTiXR/ozxmPPls6fby3JJ52W2neaipocSfaNvx4hF+SmoU4tOWDhuf9GD6aitnhk8kyhookAzsgKQR2uGy2DMB4bX1NT+j+WvjMBFnzyPhs40BfGDQdwGUWHlvWD6LCdsRhF8ElZz/u6fCp1ExBveVUAJBy9vbQi0SqL3+9XybDROG+unkZVzuEeJMoGhYq2dreh3q9tdfFdkxCx6LIr+Kxk7675LnnWtHxR3kyiWKNb2zO0ifDOK2MecMI2fPNYaA9YDcnawGHW/LnUj0OwccIleQJIHKqmdEcgqLuwJF/aJXxy3qfm1uNnrcwXAYJrM/FcMXtb6t0zWvfLd5CbX8KkU6BYY3IxTsTuQ8R/szXqKXBuXEmGQgBSCI4x7RcEEFD+aPf4V6OB4Yf8A08YPjBCfkFqbTQvQaICwxUq/px//AJ14HQmMbYxz+Lq2+QWsyYHDD2HRfKN0/wDrc18bA/mzJ6yzj4PpTtUTi+hUhkCLjE1V3BaM6ZGRbdmQ79YPdUl0S6JvhsQ0ksyyEoVXIpAUF1LE5uZso08a8S4eRJEBcEsGUfWRkfZa17DL7POvb4PEEG0ZOhGgD7jfsN5cqbqaYeO8NxE8irhZTEQplbtyICZOr5IDfe1zt61k6P8AR6WF5JMS6TtIqhrhibqb3LG19LDbkKgoIZs7q6S9YrhoQe0yIeqzg5dVBG+bskXBuSLTZ4gym2dl8CSPgauVs8SSX1Jz8Awch7WFAPepAPpYA/Go7C4XClXMLyOLFcsivkOSRdUc3vYobdq1idK9JxiTlJfzANacMkcbPKEAJSQEDsg9YwYkADKCGUftNvfSS39WyfiW4c+KyKYcTFkXsCORB2MnYKBiQSAVIB7q2OJYjHSQSxPhY3EkckeaORltnQpezAg799RnR3i8YhAdGGa8yEWYlJWZxmF+yVJy8wdCOYEsvFMPvdge/Kf4VednScJWCfGtPjo5TDJEFjKv1gFrqzMLMpIOrc7Hw7uiKwNc3Tij9c4aYPC1ityRlARewQV1OcE3v9o91VzorhcWwxL4bGtDbFTApkV0a2UhrNqLg20/NFamX6lxdspXOo8dxqP7eGmH30dCfVGI+FbK9MMcmkvDsw74plP+66r861yjPCr5Sq5wDpSmKkMXUTQsouRKqqP0SGOY+W1WOrLtLClKVUKUpQV3pjjGjiVEXM8riNVvbMSDZSeSk2BPJS1RCYHFNHYyqQDlYNEoQ2tfKBoq3vob2033rB0i4qHx8UYayRxuwNxqzq6gm/Lsj31GXDuzBgXRmKZ3VYyxYspy7ZlZr5tLC19xTjv1ZlrxWumWKjjdUwyKrFglspUNJmynsk2tpcEcn8qgZsfIIzJo2Z8kIy2zWNi1r6gm9vI1tcfzmcn2urhe2S7LnIKKqH7WUtcHmFvWvjYWWWNYwGTDxdk7q0gS667Fg7X9DREvwnHvhsNica5RijfRcOMos0rAF213VRfzF6zdG+L4iWVmlcJDDF9JxAVNBpdI1U3AZgFNwL6G1iKjOMxZsNw/CJ2o416zEZTs8j3dT95VuPUUYsvDZIlW+IxOJzzKN0iQAopOxu1yADsaIiG4jPOxfOyvPKcg0OVb3diSLsBcKPwt3UxWILTsquwihUl8rkZsu4JvuzFU9a3cBg2STPkb6uLJFt2ny3N9dLuz794rQg4TKIijIQzyLnN10RbnTXW7MSR/oxRUlw7AuIEN/r8U+VOeRN2exPshAW/SXurqvRXAxxwWjKlFDIjKoDG1w5Lakm9xpbnvVW6M4jCNJJPLOsQQfR4UIzEKqjOw7rsct/u+NWPDdIeHwwpDFiVOTRTIwRTffM9rAk63ta/dREOxwiLOcQHciUIiBpC+UJGRkJYWBZm202rHwqJOsM6xmFFSQkPIzsYjHICXVwSvbCWAJGq94rVxUuDllZnkisxBYnGR8gFzdk6iwAsL1H4riGEQPFErOshXrJOsILZDcIgYXEYPa1sWOtgAKKgcdOgMYRSbkKWYdkWALFQRmY6XF8tu6pnAzMI16uJ3Q3bPsCWJJI07QvpewBtpUTxeWEzQrldY+yHW+ZxGWXrHFralRYczc94qycU6T4ZF7OcadlchWwGgt4DQelZmOOtN5Z5W7rWMsbsAwAa1hcPfyuo86zdRGP6VV852T4OwqjY/pHMxKxu0aX2RirN4uym58F2HjudSHjuLT2cTMP1jEe4mnCJzrpC4Vz7EpPgk0bn9k5ifdWIiRTYyPcbhlS/eNAoIqip0qxn2pcw+9HG37yGpjA9LJGyrNGjx96II3TxXL2T+Eix8NxLhPxqZ39WAvIzKOsBa5ykqTY769vUeorOHxA3eNrfdZe7vY1pStZlswIPaVhsysl1YeBBB79dda2oMdYWNib6Ei599/G1eb/S5Tx34b7r4mKkEmdSA4GvaKgiyLbMATzB25Vtpx/FDdm9JCfgwFaSREzMuidgtYnLZfq9be731jxEZQ2Ot9VI2Yd4Na5y2TfbFxsSJ47IfajDeaQt8zesWI4mroy9Sqkg9oRlbaX3U5a0Y0LbbDc62F9B5knQAak1tYsRxxspF3YHS+q6HVraX8P8AuZc5Lx9pMennhONjSMLJGSQWsQXUABjlAsCot5edbQ4hhD9tl/WRn4FB86jOHws8fYFyLki4vvfbekKszZRv46WtuWvsBzrVynffi8L0k5JIiCUkYm2gKrr+krn5VE9GUDLP21U/SJPaD63C81U2rJZM3ZAIXUtaxPj4X2A8RzJrQ4XgpPrFypnMrtla4ezBSCOZBFj6mtzuM5dVZhEw9mSP0ky/vgV7H0geyzH8Mit8Fc1CSYSWMXeNguxZHdrX2LBdl8TtWMvp7TftX/evU0bXHovJMcZHnWTcglg1h9W9rnb3100Vxjoa3+PQDOfaO+XW0bkDQV2gV0w8c8/SlKVtgqpdKekjR3hgF5NMzXACX1sBuWtbyvVtrl/FsZhhjm63D2+tymXrHyXBADOmq8gNbD3VnLf4s1+q9xOCeSTOIGRNCEtIwBFrkPmBOoB12PlWp9GMjhZER2W+hzOV77lnIQd+YipqfHZ8TiTG10Dot1Y2LCJQ9iD+GvfCOG3ZIkkVQxC+wCfMg6E1zyt3p1kmtqNjp0kOURiEox7cRzpIL2Oi5bjS4bnr317TDQ88W/pDJ8+srp/EeGvh+rvOT1kgQZYENrgm518NudahlYI7/SPZXMFWONi2qaDIx1GdSw3XnyJ1OTP81zd8PENppH/VW+cteVijvq7/AOyB/tf7/PpsjyIXBmfsZderjAbMhfsEkZzZSABfMbWtU2eATf8AvHH6pR/Wp/RrFxzqYDp1jjlb6OD/AGw51NcE4dF1TtHBJOzHLmaNYkCgAsq9tySxtmO1hYWNzVlEkmUM2JOoBsEOlxe3tC9aXEcSLZhp8N9SbA2FySfWs3O1qYRHYmHEIP8AIRxLYntZhYc2uXAC+NrVjkwGL+0yL+ko/rmp/g3EIUhu8iq4LF85y8zlbXcZbC45gjeqxh+OYcdYVw3WXkcobvbLfSyotrXvbzFa4s8n2TBygXaZR5G/yrSnkybyux7lW5/nUivHpP6LCRoOR6sA+92HyqH4xxbElhmkyg27K5fLkotUXb1hcVMFfq0dEaxdmW7HkLmwsNdBtc1CcasrIgH2LnvJZydfQA+tTODkkYaux7wWJB9Kr3F2z4h7cjkH6AC/MVcfWcvGqMMx2t371nw/CppP8mhfxF7cuZ05iprgnDlbtPqARZdNSdQGBPskAi/hfYGrM/E4YFsUVyNrmyjeyqBa9gSLnkdheujDnWKwckZtIjITtmBF9AdO/ce+mGblXRk49hcVeGWFQHuAycjYnMVO+176HuIqm9IODthJ8pOZG7SMNQynTfw1Hp6AJngGPzRBCiMYmv2lv9W4YWve9lkYf7QVLRcRKtmVEB5WXbxGu9VLgj5ZguwclD+sFlv5NkP6NS5krjnhLe464Z2N6HE50lSTUtkKlyGysqKCw1ve9iGGum2prPhsYLGNwShOw3U/nJ/LnUG8hD3sbWIuATvltoOXZPw76+/SR3N+w/8AKs5YSzTeOek/LxAKAIxlAvl55b6FvvSHm3IGw76j2kJvY6m9aP0jwf8AZb+NZIJbkmxAXU308h6nT1qY/wCcx8W5/G/HKqxxOpCvkGfLa5I+0baXt6m+t9LZpuJlkK2szHtvzYch4c6hFmt2bXtYDVRsLbEjx9LV7RmYgBGJOg2/gatwlu6zMrrUb2ImsFUbaE+ZAJ9wIHoe+vGKxbQ4dpgx62V8kbbkWAeVxf7QHVqDyz1rO2ZjbbU+8hR8xVmxPDoBFC2JGaOONnCD7TyvY3tqOzHHbYG55A26/wCcc81GPSPGsbHFzeFpGX921TGHxZdEdjdmW7GwFyGKsbDmSt/WoPjuEiVllgDCJmtlJzZGGuXNzuLkb7HU1scNltFbTR3Gp7wh+ZNXPuJh1Vw6FvfiGH/Gf3HruIrhfQFGbiOH0tYu2x2Eb13QUx8XP0pSlaYK4b0wW+La+wxT37tnCE+vzruVce6XQouLmR2KFmzgspZGVwDe66rrcagjS9xtWcmsWtw+WMR5WfIRmINrrl3ysAL75jfXfbnWtwrpAiy/SchXDwuhdixzHOSLImXta2NmINQeKks7IGVgezddVNxqQdL7n41uQ4LDSQGN8WIy5uylT2WU2BO2YaX3G9c9bu2/zTpH+G2CkFzDiWXkThnYelr1D8c43gJspEc6sOzrBMgyk3JGVCQ1wNeYuOdU4cJjHs8Wi8iuX+0r7/4e/wBni0HrJl/tK67jnxqXbGYLU5pbk3uUxROsis1rpYDItststydAKsHBemnD8PEqPI+YFmc9VOQSTckF1vtbQ1SRw3FfZ4hh2/XH/npiOB46QBWxEEgAsoMjHnfSx72531NNmnvh3EJcTdYoWbIqse2gOXMUuFYi+21+Y76nisUahmYXIuovnc3Gma1gg8N/Oq/wfo3i4ZlkJjAsyuQ+YlSp0I0B1AN7jYHWvXG8LJG3WMQVdmOgtZtyCLnc5j+13Vyynx0xtvqBwU7GfENLZ5RG5jLDNYqLjKDt2bWFbXD4AyIzWZiuYsdTc3PPbyrRxhKOk67oRm8V5/Aketb2HFhaNWIJzAAkjXU2Fr691+dbmSZT424pAARe+vzAPzN/Wobi0l2FSjYKe1+pcDfMy5F8yzWHx7qhcfEQQS6HwRg9vMr2fjWL6s8SvD2Ci52Gp9NTVawymRyxtckt+0b/AMTU20loXP3SB5t2R86iMGba2uBr68v7g1vBnNPriMqcyFGUA2J31GneRbnovO9bEPRt3iOLxEy4eLSzlGkY3OUZEW3ZubZiQLmtbhUXWMkbk5Ls8xF79XChkfyJC6H861WroHifpk0jTorI4kZYzfLGrKIwgAsMnV5UyneyncA1thVOI8EaKNcTDMs8BPtqjRuhDAZnjYkhbsozAkdod9fJ8T9IwbRP7cP1iHW9r2cab3B958q6ZI+EjiOEhhYXkaNCxWRJJFt1uFL52McjorKFe3LmK5kcIcNi3hN+w7x76ldQt/HKVPnQQMZII11AFj5bGrViERiJesVFlu6grI2pP1i3VCvZe4te4BXvqqxr2gvmuvev/attlmKdUGITNny/eAKg+4n+9rSzay6Tgji/z4P6qQ/Mqa8kQjeQn/46H4vLUTDwedxZI5HOmqo7anvsNjUhD0PxrRuOodSTGRnyptnDe2Rtce+s8WuT2cVh1+048lgj/g1eTxKA2H1jdwM0dr23sIrVs4f8n2LO4Rf0wf3M1SMX5P5BYmRFIOvZdr+HaC/CnFOSHPEo0W4jcDfWV7a+CBawJxZJCQsat+IzH5y/wq1f+X4KKrSSPYAdiMAmw3uWYfCtKPofJF1gEUlyy5C0kIzL95WKm++1qvCHKtHAZpHVRGiA6dkHMdbgasbC9vcKsWOijxONaCQ/VRZUVQ2UvIFCRR3+zmZWufA1rdFsL/jKXIYL2yQbgALmseQI2I5GsHRDEQviC8oJeWRZISM2W6GXfKbas6CxHI7VqTUY3uo7pPwBsKXhIYRyQ/SI8xzFHjYZ0ut8xGozdxGu9YOgEEUuJ6ibEPAsgGVo2CMzqcqpcgjtZ235gW3qz9MFACza5ZOsvmsGDTYea6tb2TYIp30RRyvXPuCG0+HPdLEf+IlFfoPhPQjC4eVJleZ5E2Z5Wa+hGqiwPtHS3OrSKUoFKUoFU/pl0RbGskkcio6Aqcylg4vdRdSCpBzcj7VXCvtSzZt+Z8XG8bMGUdkkHfTKWB5fdb3Vr4jiSLoyEm+pB2HPcanw+VWbpPhjHiJ4zp9Y2X9Ikr786fHuqkcSF2uOYvfv+HdU4RrnW+3EILaFzfTRbEeOuh8qyiaIqWDMwG9lYEePaAFvWqwj2NSGGnCg6izCxHPUW99ThDnUuHhtfrEPheza/da2vhX1Y4m9l0PgzIp9QTUAp8jvyvWZCPL4U4RedTqYWNjZSpOtxpf+RrYjhWM9vRWFiNrjwIG4NiPIVoYDCSS6JE8l9Pq43fX9FSPiKmv/AC34hcSLhiAQDlzR3HhbOLeVOBzRht/LxFbX/iM2UL10mUCwAkYADusDtW8eh/EFv/icgFjoBGwvpY2DGo5ujfEVbtYfEFb8oGJ9csZ+FTgc2q9jqdT3nU+81p4txas/EUdCUyurg2YOuTL+IMAb1iwkbM1jIL2J1AAuFJ35bU4VecaOIxJEYTvNz5DUfG3urFAQByvp4HepfF8N1JJJa5Ha/ArAEnYa632OnOo3FIFKgXsQDqCP4VuTTFu1i4HieqjaYlgFRFBS2ZTI5VWUHexU91XrAcdjhhjks0hkeOJmjjVWLuDd3RdBqL6X9oW3qgcPg6zDOgIBIiYZmCg9XKMwuTa+Vyf0TVp4Zikgiz5wVHbJXUWCgXHeOz8aqLHx/DKuEmMKLnldZ3tcFXVlbrhc6soS/LUHxqh9NAG4g8gW/WxwykDmXhW49SvxqyrjWeJVjBbroyFJGUxh0ATrO9u0q6G3tHwqpdJsUsmLdlYFECRoRzVIlUEeoPuoKvMxzudjnc+V2Jrx1rfnN76+SOcz/ibz3IrJg8K0sixqVBJAzMbKo5sx5AUF36HdGMbi067DOYU1AcuVViDZlAQkmxvuLaV0PAcD4qGQSzwFVvnIzsz6G1wFWxBtrflW90c4rw/C4eLDxYhSsahb7Zjuzkd7MSfWptOPYVtpk99BWuL8G4kqkwPh5Gt7LKyHyBJYe8itXo5wDiUjlsbKsSD2UhPbb8T6hV8tT3i2t3TiELbSKfUVlWdDs6n1FBz3pV0TxFnfDzYlxkZgnWJoQDYAGMsw8L35VyHHYPHZeskixQQC7OyShBy1JAA176/UgYd4qO49w0YrDTQE26xGQHuJGh9DY+lB+XcLK8ZzRu6HvRmU2PLQ6jwq5dGcYkUXWdWXdWKKFNyM4ZiMvI22JIFwdzYCk2KMUcFWUlWU7hlNip7iCLVO8Ix2UsmfKGXsmwsGFrE33Nha/LUjUCgsvSG8scGGjYPJJKX0uArMvVxob7aSMx5AW35uC/ky4guIhaWNFjWRHdhIrHKjBjYbk6W9akug2HXE8SVo0Cx4ZS7AXsHdSqDUnU3Y630QbkXrslApSlApSlAr7XyvjOBuQKDnP5TOCHs4lL20SS3LWyP56gX8Frj2Pi1v7uY2F7HuFxr3Ed9fpPiPEsLkZJWVlYFWUi4IIsQRzriHS7hUMbs2FmEiHXI9w6b6Bjo4152Pffegoc8fMViz+FbeIe3KtZpR3UHkympHo9waXGYhIIwSzmxNtFX7THwA19w51qYfDM5too5lth/E10nolxSHARlYTd39uQgZmtyH5qDkO8m5PIO1cMwCYeGOGMWRFCL5AWvpzO/ma27gc65SemDt9tq8npGT9o++g6o2IQbuo9RWF+IxDdxXLjxzxrweMeNBeuMrgMSAJ41kt7JIsy/hcWYehqq4/o5w9Ed4I5EkVSUJkkZb2O6s1iLXqMfip76wNxJu+gruJXLl5gZb2F72VoydtbtY/hXXUVXuJroh15qe66kg29QfdVkxjDMQdBqb72DWBPoch9/mIPiEdwR+lYciNGGncbe/1oNzo7IGUKWy5WuSNbDdjbmANbc8oArd4fJNHK8crWyMEtZQhVh2MijTKQVItuDVa4bijFIGuQDzHI/Zax8a6BgMJHiMjLLGHS4OHn1j5m0ZDKeruSQtyRtoNKD1guPQte0a5EvmyBiJGCtZQzMbBjZLjSzEjSqniAzyDPq8jtI55EsxY27he+njVw4rHDBd5WhzhQqxwKiKLXtZVJyjU9piTqQKiOCcLfEFpsu/ZGnK99O7TL6WPOgjpMFGfsD3V8XALyQVdYOikjbIT6VJYfoRKd1A86CgJhyNhW1HmHfXR4Ogn5zgeQqRg6FwL7TM3uFBzJJpBzNbCYqbkW9L11aDo3hU/owfPWpCLBxp7MajyAoOSwfT3/yaSH0NbQwPGvsqw8z/ANa6wKUHBuK/k64lipTK6Irt7TXAzH84/e8edZML+SLHGweSJR36kj3Gu60oK/0P6NR8Pg6pLFiczvrdmta58ANAKsFKUClKUClKUCsM2HDVmr6KCDxXAlfkKg8X0RVv6MGrxXy1ByzE9CU/zQ91R79DEH9H8K7HavJjHcKDjP8Agko/o/hX0dGwPs12FsKh+yKxPw+M/ZqDko4DblXxuDkcq6u3CIzyrXfgUZoOVPw1hWu+FYV1d+jqHnWu/RdTQcocEVrvPaurSdD1PdWrJ0ERuQoOTY6VHFs1iNj8wfA1AzYix13+Hv532/6122X8nEbd1a5/JRC27AelUcTLKf8Av/fSs8TkCyvYdx/nXaE/JDgvtM58rCpHCfku4ZGbmEv+JiR7hQcp6McEkxsgUMCgIzuR9Wvy6w/dX1IFd74TwyKCNI0XRRYEjU8yT4kkmsmB4XBCMsUSIB+aoHxreoPgpSlApSlApSlApSlApSlApSlApSlApSlB6pSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlB//Z',
    },
    {
      name: '407',
      weight: 500,
      img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRJemlHhyIYd9riyxsK6ieol7XMkQEgokkSVVTF-BlrJQ&s',
    },
    {
      name: 'Eicher',
      weight: 500,
      img: 'https://cms.eichertrucksandbuses.com/uploads/truck/exterior/1fe8eb8b0a37d7f2cf8f80ac9cd247a3.png',
    },
  ];

  const goods = [
    {label: 'Cartoon Box', value: '1'},
    {label: 'Wood', value: '2'},
    {label: 'Steel', value: '3'},
  ];

  const fare = [
    {label: 'Item 1', value: '1'},
    {label: 'Item 2', value: '2'},
    {label: 'Item 3', value: '3'},
    {label: 'Item 4', value: '2'},
    {label: 'Item 5', value: '3'},
    {label: 'Item 6', value: '2'},
    {label: 'Item 7', value: '3'},
  ];

  const vehicle = [
    {label: '1', value: '1'},
    {label: '2', value: '2'},
    {label: '3', value: '3'},
  ];

  const options = {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: "2-digit",
    hour12: false,
  };

  const checkPermission = async () => {
    try {
        const granted = await PermissionsAndroid.request(
            PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
            {
                title: 'Storage Permission Required',
                message: 'Application needs access to your storage to download File',
            }
        );
        if (granted !== PermissionsAndroid.RESULTS.GRANTED) {
            Alert.alert('Error', 'Storage Permission Not Granted');
        }
    } catch (err) {
        console.error('Error requesting storage permission:', err);
    }
};

  return (
    <>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.header}>Choose Your Vehicle</Text>
        <FlatList
          data={VehicleData}
          horizontal
          showsHorizontalScrollIndicator={false}
          renderItem={({item, index}) => {
            const isFocused = selectedVehicle ? item.name == selectedVehicle.name : false;
           
            return (
              <TouchableOpacity
                style={[
                  styles.vehicle,
                  isFocused
                    ? {
                        borderWidth: 1,
                        borderColor: Colors.primaryColor,
                      }
                    : null,
                ]}
                key={index}
                onPress={() => setSelectedVehicle(item)}>
                <Image style={styles.vehicleImg} source={{uri: item.img}} />
                <Text style={styles.vehicleName}>{item.name}</Text>
                <Text style={styles.vehicleName}>{item.weight}</Text>
              </TouchableOpacity>
            );
          }}
        />
        <View style={styles.typeView}>
          <Text style={styles.h3}>Vehicle Type: </Text>
          <TouchableOpacity>
            <Text style={styles.h3}>Select Type</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.line} />
        <View style={styles.dateView}>
          <Text style={styles.h3}>Date & Time:</Text>
          <TouchableOpacity style={styles.selectDate} onPress={() => setOpen(true)}>
          <Icon name="calendar" size={15} color="#000" />
          {dateSelected ? <Text style={styles.h3}>{date.toLocaleDateString('en-US', options).toString()}</Text>
          :<Text style={styles.h3}>Select Date</Text>
          }
          </TouchableOpacity>
          <DatePicker
            modal
            open={open}
            date={date}
            onConfirm={date => {
              setOpen(false);
              setDate(date);
              setDateSelected(true)
            }}
            onCancel={() => {
              setOpen(false);
            }}
          />
        </View>
        <View style={styles.locationView}>
          <View style={styles.locationTextView}>
            <Text style={styles.h3}>Pickup Location:</Text>
            <Text style={styles.h3}>Drop Location:</Text>
          </View>
          <TouchableOpacity onPress={() => navigation.navigate('Map')}>
            <Text style={styles.location}>Choose Location</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.line} />
        <View style={styles.dropView}>
          <View style={styles.dropView1}>
            <Text style={styles.h2}>Goods Name:</Text>
            <Text style={styles.h2}>Fare Type:</Text>
            <Text style={styles.h2}>Number of Vehicles:</Text>
          </View>
          <View>
            <Dropdown
              style={styles.dropdown}
              containerStyle={styles.dropContainer}
              itemTextStyle={styles.dropTextStyle}
              placeholderStyle={styles.placeholderStyle}
              selectedTextStyle={styles.selectedTextStyle}
              iconStyle={styles.iconStyle}
              iconColor={Colors.white}
              data={goods}
              maxHeight={200}
              labelField="label"
              valueField="label"
              placeholder="Select item"
              value={goodsName}
              onChange={item => {
                setGoodsName(item.label);
              }}
            />
            <Dropdown
              style={styles.dropdown}
              containerStyle={styles.dropContainer}
              itemTextStyle={styles.dropTextStyle}
              placeholderStyle={styles.placeholderStyle}
              selectedTextStyle={styles.selectedTextStyle}
              iconStyle={styles.iconStyle}
              iconColor={Colors.white}
              data={fare}
              maxHeight={200}
              labelField="label"
              valueField="label"
              placeholder="Select item"
              value={FareType}
              onChange={item => {
                setFareType(item.label);
              }}
            />
            <Dropdown
              style={styles.dropdown}
              containerStyle={styles.dropContainer}
              itemTextStyle={styles.dropTextStyle}
              placeholderStyle={styles.placeholderStyle}
              selectedTextStyle={styles.selectedTextStyle}
              iconStyle={styles.iconStyle}
              iconColor={Colors.white}
              data={vehicle}
              maxHeight={200}
              labelField="label"
              valueField="label"
              placeholder="Select item"
              value={noVehicles}
              onChange={item => {
                setNoVehicles(item.label);
              }}
            />
          </View>
        </View>
        <View style={styles.numberHeader}>
        <Text style={styles.alterNumber}>Alternative Mobile Number</Text>
        <Text style={styles.optional}>(optional)</Text>
        </View>
        <View style={styles.numberView}>
          <Text style={styles.numberText}>+91-</Text>
          <TextInput
            style={styles.numberInput}
            placeholder="Alternative Mobile Number....."
            placeholderTextColor={Colors.black3}
            keyboardType="phone-pad"
            onChangeText={text => setAlterNUmber(text)}
          />
        </View>
      </ScrollView>
      <TouchableOpacity
        style={styles.next}
        onPress={() => navigation.navigate('BookingSummary')}>
        <Text style={styles.nextText}>Next</Text>
        <Icon name="arrow-circle-right" size={25} color="#fff" />
      </TouchableOpacity>
    </>
  );
};

export default Home;

const {width, height} = Dimensions.get('screen');

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: width * 0.04,
    backgroundColor: Colors.white,
  },
  header: {
    color: Colors.black,
    fontSize: 18,
    paddingTop: height * 0.02,
  },
  vehicle: {
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: width * 0.02,
    marginVertical: width * 0.03,
  },
  vehicleImg: {
    width: width * 0.23,
    height: height * 0.08,
    resizeMode: 'contain',
  },
  vehicleName: {
    color: Colors.black,
    fontSize: 14,
  },
  typeView: {
    flexDirection: 'row',
    justifyContent: 'Flex-start',
    alignItems: 'center',
    gap: width * 0.06,
    marginTop: height * 0.01,
  },
  line: {
    marginVertical: height * 0.02,
    borderBottomColor: '#cccccc',
    borderBottomWidth: 1,
    width: '100%', 
  },
  h3: {
    color: Colors.black,
    fontSize: 14,
  },
  dateView: {
    flexDirection: 'row',
    justifyContent: 'Flex-start',
    alignItems: 'center',
    gap: width * 0.18,
  },
  selectDate: {
    backgroundColor: Colors.steel,
    padding: width* 0.01,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 5,
    gap: width* 0.01,
  },
  locationView: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: width * 0.1,
  },
  locationTextView: {
    marginTop: height * 0.03,
    gap: height * 0.03,
  },
  location: {
    color: Colors.white,
    backgroundColor: Colors.primaryColor,
    padding: width * 0.02,
    borderRadius: 5,
  },
  h2: {
    color: Colors.black,
    fontSize: 14,
  },
  //dropdown
  dropView: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  dropView1: {
    gap: height * 0.045,
  },
  dropdown: {
    margin: 10,
    height: 35,
    width: width * 0.38,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 5,
  },
  dropContainer: {
    color: Colors.black2,
  },
  placeholderStyle: {
    color: Colors.black3,
    fontSize: 14,
    marginLeft: width * 0.04,
  },
  dropTextStyle: {
    color: Colors.black,
  },
  selectedTextStyle: {
    color: Colors.black,
    fontSize: 16,
    marginLeft: width * 0.04,
  },
  iconStyle: {
    width: 20,
    height: 20,
    marginRight: 10,
    backgroundColor: Colors.primaryColor,
    borderRadius: 10,
  },
  /////
  numberHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: height * 0.02,
    gap: width* 0.01,
  },
  alterNumber: {
    color: Colors.black,
    fontSize: 15,
  },
  optional: {
    color: Colors.shadow,
  },
  numberView: {
    flexDirection: 'row',
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 5,
    marginTop: height * 0.01,
  },
  numberText: {
    color: Colors.black,
    alignSelf: 'center',
    paddingHorizontal: width * 0.03,
    fontSize: 14,
  },
  numberInput: {
    color: Colors.black,
    width: width * 0.7,
  },
  ////
  next: {
    backgroundColor: Colors.primaryColor,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: height * 0.012,
    gap: width * 0.04,
  },
  nextText: {
    fontSize: 20,
    color: Colors.white,
  },
});
